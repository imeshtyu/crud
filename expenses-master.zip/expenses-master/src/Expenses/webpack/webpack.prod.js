/**
 * This is a prod config to be merged with the Client config
 */
module.exports = {};
