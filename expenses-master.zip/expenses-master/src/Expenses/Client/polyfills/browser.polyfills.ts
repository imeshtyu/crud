import './polyfills.ts';

import 'zone.js/dist/zone';
import 'reflect-metadata';
