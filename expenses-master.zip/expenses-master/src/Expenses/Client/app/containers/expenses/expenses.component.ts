﻿import { Component } from '@angular/core';

@Component({
    selector: 'expenses',
    templateUrl: './expenses.component.html'
})
export class ExpensesComponent {
}
