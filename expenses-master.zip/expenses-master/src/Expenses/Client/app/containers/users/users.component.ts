﻿import { Component } from '@angular/core';

@Component({
    selector: 'users',
    templateUrl: './users.component.html'
})
export class UsersComponent {
}
