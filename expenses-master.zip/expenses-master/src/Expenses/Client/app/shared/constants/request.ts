import { InjectionToken } from '@angular/core';

export const REQUEST = new InjectionToken<string>('REQUEST');
