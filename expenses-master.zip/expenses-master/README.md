# Expenses
Sample project with angular 4 + ASP.NET Core

To initialize UI part of the project
1) cd src\Expenses
2) npm i
3) npm run build:dev

Start up project in the solition - <b>Expenses</b>
